export class News {
    id: Number;
    title: string;
    url: string;
    num_points: Number;
    num_comments: Number;
    author: string;
    created_at: string;
}
