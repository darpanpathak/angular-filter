import { NameFilter } from './name-filter.pipe';

describe('NameFilter', () => {
  it('create an instance', () => {
    const pipe = new NameFilter();
    expect(pipe).toBeTruthy();
  });
});
